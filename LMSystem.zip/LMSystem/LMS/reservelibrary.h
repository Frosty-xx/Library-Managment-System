#ifndef RESERVELIBRARY_H
#define RESERVELIBRARY_H

class reserveLibrary
{
public:
    reserveLibrary();
};

#endif // RESERVELIBRARY_H
