#include "Admin.h"

Admin::Admin()
{

}

Admin::~Admin()
{

}
