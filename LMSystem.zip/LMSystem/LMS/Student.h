#ifndef STUDENT_H
#define STUDENT_H
#include "User.h"

#pragma once

class Student : public User
{
public:
    Student();
    ~Student();

private:
};

#endif