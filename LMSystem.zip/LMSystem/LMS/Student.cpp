#include "Student.h"
#include "User.h"

Student::Student()
{

}

Student::~Student()
{

}