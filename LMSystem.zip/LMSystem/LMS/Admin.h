#ifndef ADMIN_H
#define ADMIN_H
#include "Resources.h"
#include "User.h"
#pragma once

class Admin:public User
{
public:
    Admin();
    ~Admin();

private:
};

#endif